from pathlib import Path
import utils.io as io
import data_quality as dq
from utils.formatting import format_number

BASE_DIR = Path(__file__).parent

CUSTOMER_PATH = BASE_DIR / 'data' / 'customer.csv'
CORRECTED_PATH = BASE_DIR / 'data' / 'corrected_customer.csv'



def main():
    # dates are loaded as text and parsed later in dq.parse_dates
    customer_df = io.load_file(
        CUSTOMER_PATH,
        dtype={'CUSTOMER_ID': str, 'RISK_RATING': 'Int64', 'REGISTER_DATE': str}
    )

    customer_df = dq.drop_unrecoverable_rows(customer_df)
    customer_df = dq.repair_typos(customer_df)
    customer_df = dq.fill_blanks(customer_df)
    customer_df = dq.parse_dates(customer_df)
    customer_df = dq.repair_dates(customer_df)

    problem_count = dq.final_check(customer_df)

    # save only if final check found nothing
    if problem_count == 0:
        io.save_file(customer_df, CORRECTED_PATH, False)
        print("\nFinal check: no problems found")
        print(f"Corrected table saved to {CORRECTED_PATH} ({format_number(len(customer_df), 0)} rows)")
    else:
        print(f"\nFinal check: {format_number(problem_count, 0)} problems found, table not saved")

if __name__ == '__main__':
    main()
