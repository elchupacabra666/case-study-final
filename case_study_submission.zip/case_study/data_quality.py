from rapidfuzz import process, distance
import pandas as pd
from datetime import datetime
from numbers import Integral
from pathlib import Path
import utils.io as io
from utils.formatting import format_number, print_table


ERRORS_PATH = Path(__file__).parent / 'data' / 'error_rows.csv'

code_to_name = {
    'PER': 'Personal Customer',
    'PUB': 'Public Institution',
    'PBANK': 'Private Banking',
    'GOVT': 'Government institution',
    'ENTR': 'Entrepreneur',
    'EMP': 'Employee',
    'SME': 'Small and medium-sized enterprise',
    'LCORP': 'Large Corporate',
    'FIN': 'Financial institution'
}

value_to_risk = {
    1: 'Low',
    2: 'Medium',
    3: 'High'
}

# everything else is made from the two dicts above
name_to_code = {name: code for code, name in code_to_name.items()}
risk_to_value = {risk: value for value, risk in value_to_risk.items()}

SEGMENT_CODES = list(code_to_name.keys())
SEGMENT_NAMES = list(code_to_name.values())
RISK_RATING_NAMES = list(value_to_risk.values())

def find_unrecoverable_rows(df):
    # Rows are unrecoverable when both values for either field group are missing.
    blank_segments = df['SEGMENT_CODE'].isna() & df['SEGMENT_NAME'].isna()
    blank_risks = df['RISK_RATING'].isna() & df['RISK_RATING_NAME'].isna()

    # same customer id more than once - cant tell which row is right, so both go out
    duplicate_ids = df['CUSTOMER_ID'].duplicated(keep=False)

    unrecoverable_mask = blank_segments | blank_risks | duplicate_ids

    df_unrecoverable = df.loc[unrecoverable_mask].copy()
    df_unrecoverable['ERROR_REASON'] = ""
    df_unrecoverable.loc[blank_segments[unrecoverable_mask], 'ERROR_REASON'] += (
        "Missing both Segment Code and Name. "
    )
    df_unrecoverable.loc[blank_risks[unrecoverable_mask], 'ERROR_REASON'] += (
        "Missing both Risk Rating and Name. "
    )
    df_unrecoverable.loc[duplicate_ids[unrecoverable_mask], 'ERROR_REASON'] += (
        "Duplicate Customer ID."
    )
    df_unrecoverable['ERROR_REASON'] = df_unrecoverable['ERROR_REASON'].str.strip()

    return df_unrecoverable, ~unrecoverable_mask

def drop_unrecoverable_rows(df):
    df_quarantine, recoverable_mask = find_unrecoverable_rows(df)

    # overwrite the file every run, otherwise same rows get added again and again
    io.save_file(df_quarantine, ERRORS_PATH, append=False)

    print(f"Unrecoverable rows removed: {format_number(len(df_quarantine), 0)} (saved to {ERRORS_PATH})")
    for reason, count in df_quarantine['ERROR_REASON'].value_counts().items():
        print(f"    {reason.rstrip('.')}: {format_number(count, 0)}")

    return df.loc[recoverable_mask].copy()


# how many values were changed by a step (blank values dont count)
def count_changes(before, after):
    return ((before != after) & before.notna()).sum()


# how many blank values were filled by a step
def count_filled(before, after):
    return (before.isna() & after.notna()).sum()

def repair_word(word, correct_words):

    # word is correct, return it
    if word in correct_words:
        return word

    # find closest match from list
    # score_cutoff = 1 allows only 1 letter change

    match = process.extractOne(word, correct_words, scorer = distance.Levenshtein.distance, score_cutoff=1)

    # if match exists, return match
    # else return original word
    if match:
        return match[0]
    else:
        return word


# function to repair entire dataset
def repair_typos(df):
    original = df
    df = df.copy()

    # remove spaces at start/end first (' PER', 'High ')
    df['SEGMENT_CODE'] = df['SEGMENT_CODE'].str.strip()
    df['SEGMENT_NAME'] = df['SEGMENT_NAME'].str.strip()
    df['RISK_RATING_NAME'] = df['RISK_RATING_NAME'].str.strip()

    print("Spaces removed:")
    for column in ['SEGMENT_CODE', 'SEGMENT_NAME', 'RISK_RATING_NAME']:
        print(f"    {column}: {format_number(count_changes(original[column], df[column]), 0)}")

    stripped = df.copy()

    # repair segment names
    df['SEGMENT_NAME'] = df['SEGMENT_NAME'].apply(repair_word, args=(SEGMENT_NAMES,))


    # repair risk ratings
    df['RISK_RATING_NAME'] = df['RISK_RATING_NAME'].apply(repair_word, args=(RISK_RATING_NAMES,))

    print("Typos fixed (1 character wrong):")
    for column in ['SEGMENT_NAME', 'RISK_RATING_NAME']:
        print(f"    {column}: {format_number(count_changes(stripped[column], df[column]), 0)}")


    # codes are not fuzzy repaired - 1 letter change in 3 letter code is too much (PUR -> PER or PUB?)
    # wrong code is set to blank and fill_blanks gets it back from segment name
    wrong_codes = ~df['SEGMENT_CODE'].isin(SEGMENT_CODES) & df['SEGMENT_CODE'].notna()
    df.loc[wrong_codes, 'SEGMENT_CODE'] = None

    print(f"Wrong segment codes set to blank: {format_number(wrong_codes.sum(), 0)}")

    return df


def fill_blanks(df):
    original = df
    df = df.copy()

    # create column of names that are derived from segment codes
    mapped_names = df['SEGMENT_CODE'].map(code_to_name)

    # fill blanks that are missing names but not codes
    df['SEGMENT_NAME'] = df['SEGMENT_NAME'].fillna(mapped_names)


    # same but codes
    mapped_codes = df['SEGMENT_NAME'].map(name_to_code)

    df['SEGMENT_CODE'] = df['SEGMENT_CODE'].fillna(mapped_codes)

    # same but risks
    mapped_risk_names = df['RISK_RATING'].map(value_to_risk)

    df['RISK_RATING_NAME'] = df['RISK_RATING_NAME'].fillna(mapped_risk_names)


    # same but risk values
    mapped_risk_values = df['RISK_RATING_NAME'].map(risk_to_value)

    df['RISK_RATING'] = df['RISK_RATING'].fillna(mapped_risk_values)

    print("Blanks filled from the matching column:")
    for column in ['SEGMENT_CODE', 'SEGMENT_NAME', 'RISK_RATING', 'RISK_RATING_NAME']:
        print(f"    {column}: {format_number(count_filled(original[column], df[column]), 0)}")

    return df


def parse_dates(df):
    df = df.copy()

    # file has 2 formats: 2016-10-15 and 15.10.2016
    # each format is parsed separately so day and month never get swapped
    iso_dates = pd.to_datetime(df['REGISTER_DATE'], format='%Y-%m-%d', errors='coerce')
    dot_dates = pd.to_datetime(df['REGISTER_DATE'], format='%d.%m.%Y', errors='coerce')
    parsed_dates = iso_dates.fillna(dot_dates)

    # invalid dates are rows that arent blank in original df, but didnt parse in either format
    invalid_dates = df[parsed_dates.isna() & df['REGISTER_DATE'].notna()]

    print(f"Dates converted from 15.10.2016 to 2016-10-15 format: {format_number((iso_dates.isna() & dot_dates.notna()).sum(), 0)}")

    print_problem("Invalid dates (wrong format or impossible dates), will be filled like blanks", invalid_dates)

    df['REGISTER_DATE'] = parsed_dates

    return df


def repair_dates(df):
    df = df.copy()

    median_date = df['REGISTER_DATE'].median()
    blank_count = df['REGISTER_DATE'].isna().sum()
    df['REGISTER_DATE'] = df['REGISTER_DATE'].fillna(median_date)

    print(f"Blank dates filled with the median ({median_date.date()}): {format_number(blank_count, 0)}")

    return df


# prints the count and the rows, but only if there is something wrong
def print_problem(message, rows):
    if len(rows) > 0:
        print(f"{message}: {format_number(len(rows), 0)}")
        print_table(rows, index=False)





def check_data_types(df):
    bad_customer_ids = df[df['CUSTOMER_ID'].notna() & ~df['CUSTOMER_ID'].apply(lambda value: isinstance(value, str))]
    bad_segment_codes = df[df['SEGMENT_CODE'].notna() & ~df['SEGMENT_CODE'].apply(lambda value: isinstance(value, str))]
    bad_segment_names = df[df['SEGMENT_NAME'].notna() & ~df['SEGMENT_NAME'].apply(lambda value: isinstance(value, str))]
    bad_risk_ratings = df[df['RISK_RATING'].notna() & ~df['RISK_RATING'].apply(lambda value: isinstance(value, Integral) and not isinstance(value, bool))]
    bad_risk_names = df[df['RISK_RATING_NAME'].notna() & ~df['RISK_RATING_NAME'].apply(lambda value: isinstance(value, str))]
    bad_dates = df[df['REGISTER_DATE'].notna() & ~df['REGISTER_DATE'].apply(lambda value: isinstance(value, (datetime, pd.Timestamp)))]

    bad_type_count = (len(bad_customer_ids) + len(bad_segment_codes) + len(bad_segment_names)
                      + len(bad_risk_ratings) + len(bad_risk_names) + len(bad_dates))

    print_problem("Wrong data type in CUSTOMER_ID", bad_customer_ids)
    print_problem("Wrong data type in SEGMENT_CODE", bad_segment_codes)
    print_problem("Wrong data type in SEGMENT_NAME", bad_segment_names)
    print_problem("Wrong data type in RISK_RATING", bad_risk_ratings)
    print_problem("Wrong data type in RISK_RATING_NAME", bad_risk_names)
    print_problem("Wrong data type in REGISTER_DATE", bad_dates)

    return bad_type_count


# returns number of problems found, 0 = data is ok
def final_check(df):

    # 1. check typos (segment names, segment codes, risk rating)
    # take codes/names/risks that arent (~) in white list AND arent blank

    bad_codes = df[(~df['SEGMENT_CODE'].isin(SEGMENT_CODES)) & (df['SEGMENT_CODE'].notna())]
    bad_names = df[(~df['SEGMENT_NAME'].isin(SEGMENT_NAMES)) & (df['SEGMENT_NAME'].notna())]
    bad_risks = df[(~df['RISK_RATING_NAME'].isin(RISK_RATING_NAMES)) & (df['RISK_RATING_NAME'].notna())]

    typo_count = len(bad_codes) + len(bad_names) + len(bad_risks)

    print_problem("Segment codes still wrong", bad_codes)
    print_problem("Segment names still wrong (more than 1 character wrong)", bad_names)
    print_problem("Risk names still wrong (more than 1 character wrong)", bad_risks)

    # 2. check for blanks
    blank_codes = df[df['SEGMENT_CODE'].isna()]
    blank_names = df[df['SEGMENT_NAME'].isna()]
    blank_risk_values = df[df['RISK_RATING'].isna()]
    blank_risk_names = df[df['RISK_RATING_NAME'].isna()]

    blank_count = len(blank_codes) + len(blank_names) + len(blank_risk_names) + len(blank_risk_values)

    print_problem("Segment codes still blank", blank_codes)
    print_problem("Segment names still blank", blank_names)
    print_problem("Risk ratings still blank", blank_risk_values)
    print_problem("Risk names still blank", blank_risk_names)

    # 3. check that codes and names match
    bad_segments = df[
        df['SEGMENT_CODE'].notna()
        & df['SEGMENT_NAME'].notna()
        & (df['SEGMENT_CODE'].map(code_to_name) != df['SEGMENT_NAME'])
    ]
    bad_risk_pairs = df[
        df['RISK_RATING'].notna()
        & df['RISK_RATING_NAME'].notna()
        & (df['RISK_RATING'].map(value_to_risk) != df['RISK_RATING_NAME'])
    ]

    print_problem("Segment code and name mismatches", bad_segments)
    print_problem("Risk rating and name mismatches", bad_risk_pairs)


    # 4. check dates for blanks
    blank_dates = df[df['REGISTER_DATE'].isna()]

    print_problem("Dates still blank", blank_dates)

    # 5. check that no date is in the future
    # (wrong formats are already caught in parse_dates)

    future_dates = df[df['REGISTER_DATE'] > pd.Timestamp.today()]

    print_problem("Dates in the future", future_dates)


    # check data types
    bad_type_count = check_data_types(df)


    problem_count = (typo_count + blank_count + len(bad_segments) + len(bad_risk_pairs)
                     + len(blank_dates) + len(future_dates) + bad_type_count)

    return problem_count
