from pathlib import Path
import sys

import matplotlib.pyplot as plt
import pandas as pd
from matplotlib.colors import LogNorm

PROJECT_FOLDER = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_FOLDER))

from utils.io import load_customer_data, load_transaction_data
from analysis.transactions import (
    average_transaction_by_segment,
    average_monthly_turnover_by_segment,
    domestic_international_by_segment,
    dormant_customers_by_segment,
    money_flow_by_country,
    top_five_transactions_by_risk,
    transaction_amount_distribution_by_segment,
)
from utils.formatting import format_chart_axis, format_number


OUTPUT_FOLDER = PROJECT_FOLDER / 'outputs/figures'
DARK_BLUE = '#1F4E79'


def plot_average_transaction_by_segment(average_by_segment):
    OUTPUT_FOLDER.mkdir(parents=True, exist_ok=True)

    average_by_segment = average_by_segment.rename(index={
        'Small and medium-sized enterprise': 'Small and medium-sized\nenterprise'
    })
    plot = average_by_segment.sort_values().plot(
        kind='barh', title='Average transaction amount by segment', color=DARK_BLUE
    )
    plot.set_xlim(0, average_by_segment.max() * 1.15)
    plot.set_xlabel('Average transaction amount')
    plot.set_ylabel('Segment')
    format_chart_axis(plot, 'x')
    plot.figure.tight_layout()
    plot.figure.savefig(OUTPUT_FOLDER / 'average_transaction_by_segment.png')
    plt.close(plot.figure)


def plot_average_monthly_turnover_by_segment(monthly_turnover):
    OUTPUT_FOLDER.mkdir(parents=True, exist_ok=True)
    average_by_segment = monthly_turnover.groupby('SEGMENT_NAME')[
        'AVERAGE_TURNOVER'
    ].mean().sort_values()
    segment_order = average_by_segment.index.tolist()
    segment_groups = [segment_order[:2], segment_order[2:6], segment_order[6:]]
    group_titles = ['Lower average turnover', 'Middle average turnover', 'Higher average turnover']
    chart_paths = []

    for index, segments in enumerate(segment_groups):
        chart_data = monthly_turnover[
            monthly_turnover['SEGMENT_NAME'].isin(segments)
        ].pivot(index='MONTH', columns='SEGMENT_NAME', values='AVERAGE_TURNOVER')
        chart_data = chart_data[segments]
        chart_data.index = [month.strftime('%b') for month in chart_data.index]
        chart_data = chart_data.rename(columns={
            'Small and medium-sized enterprise': 'Small and medium-sized\nenterprise'
        })
        blue_shades = ['#BDD7EE', '#7EAED8', '#4472C4', '#1F4E79']

        plot = chart_data.plot(
            kind='bar',
            color=blue_shades[:len(segments)],
            title=f'Average monthly turnover per active customer - {group_titles[index]}',
            figsize=(10, 5)
        )
        plot.set_xlabel('Month')
        plot.set_ylabel('Average monthly turnover per active customer')
        format_chart_axis(plot, 'y')
        plot.legend(title='Segment')
        plot.figure.tight_layout()

        chart_path = OUTPUT_FOLDER / f'average_monthly_turnover_by_segment_{index + 1}.png'
        plot.figure.savefig(chart_path)
        plt.close(plot.figure)
        chart_paths.append(chart_path)

    return chart_paths


def plot_transaction_amount_distribution_by_segment(transactions_by_segment):
    OUTPUT_FOLDER.mkdir(parents=True, exist_ok=True)
    segment_order = transactions_by_segment.groupby('SEGMENT_NAME')['AMOUNT'].median()
    segment_order = segment_order.sort_values().index.tolist()
    segment_groups = [segment_order[index:index + 3] for index in range(0, 9, 3)]
    graph_titles = ['Lower median amounts', 'Middle median amounts', 'Higher median amounts']
    chart_paths = []

    for index, segments in enumerate(segment_groups):
        group_data = transactions_by_segment[
            transactions_by_segment['SEGMENT_NAME'].isin(segments)
        ].copy()
        segment_labels = [
            segment.replace('Small and medium-sized enterprise',
                            'Small and medium-sized\nenterprise')
            for segment in segments
        ]
        label_changes = dict(zip(segments, segment_labels))
        group_data['SEGMENT_LABEL'] = group_data['SEGMENT_NAME'].replace(label_changes)
        group_data['SEGMENT_LABEL'] = pd.Categorical(
            group_data['SEGMENT_LABEL'], categories=segment_labels, ordered=True
        )

        figure, axis = plt.subplots(figsize=(10, 5))
        group_data.boxplot(
            column='AMOUNT',
            by='SEGMENT_LABEL',
            vert=False,
            ax=axis,
            widths=0.8,
            showfliers=False,
            boxprops={'color': DARK_BLUE},
            whiskerprops={'color': DARK_BLUE},
            capprops={'color': DARK_BLUE},
            medianprops={'color': DARK_BLUE}
        )
        axis.set_title(graph_titles[index])
        axis.set_xlabel('Transaction amount')
        axis.set_ylabel('Segment')
        format_chart_axis(axis, 'x')
        figure.suptitle('')
        figure.tight_layout()

        chart_path = OUTPUT_FOLDER / f'transaction_amount_distribution_{index + 1}.png'
        figure.savefig(chart_path)
        plt.close(figure)
        chart_paths.append(chart_path)

    return chart_paths


def plot_top_five_by_risk(top_customers):
    OUTPUT_FOLDER.mkdir(parents=True, exist_ok=True)
    chart_paths = []

    for risk, customers in top_customers.items():
        customers = customers.sort_values('AMOUNT')
        customer_ids = customers['CUSTOMER_ID'].str.lstrip('0').replace('', '0')

        figure, axis = plt.subplots(figsize=(8, 4))
        axis.barh(customer_ids, customers['AMOUNT'], height=0.45, color=DARK_BLUE)
        axis.set_title(f'Top 5 customers - {risk} risk')
        axis.set_xlabel('Transaction amount')
        axis.set_ylabel('Customer ID')
        format_chart_axis(axis, 'x')
        axis.set_xlim(0, customers['AMOUNT'].max() * 1.15)
        figure.tight_layout()

        chart_path = OUTPUT_FOLDER / f'top_five_transactions_{risk.lower()}_risk.png'
        figure.savefig(chart_path)
        plt.close(figure)
        chart_paths.append(chart_path)

    return chart_paths


def plot_days_since_transaction(customer_status):
    OUTPUT_FOLDER.mkdir(parents=True, exist_ok=True)
    days_since_transaction = customer_status['DAYS_SINCE_TXN'].dropna()
    never_active_count = (customer_status['STATUS'] == 'never active').sum()
    total_customers = len(customer_status)
    never_active_percent = never_active_count / total_customers * 100
    bin_count = int(days_since_transaction.max() * 2) + 1
    bins = [index * 0.5 - 0.25 for index in range(bin_count + 1)]

    figure, axis = plt.subplots(figsize=(8, 5))
    axis.hist(days_since_transaction, bins=bins, color=DARK_BLUE, edgecolor='white')
    axis.set_title(
        f'Days since last transaction for customers with transactions (n={format_number(len(days_since_transaction), 0)})'
    )
    axis.set_xlabel('Days since last transaction')
    axis.set_ylabel('Number of customers')
    axis.set_xticks(range(int(days_since_transaction.max()) + 1))
    axis.text(
        0.98, 0.97,
        f'Never active: {format_number(never_active_count, 0)} ({never_active_percent:.1f}% of {format_number(total_customers, 0)})',
        transform=axis.transAxes,
        ha='right',
        va='top'
    )
    figure.tight_layout()
    chart_path = OUTPUT_FOLDER / 'days_since_transaction.png'
    figure.savefig(chart_path)
    plt.close(figure)
    return chart_path


def plot_dormant_customers_by_segment(dormancy_summary):
    OUTPUT_FOLDER.mkdir(parents=True, exist_ok=True)
    dormant_percent = dormancy_summary.set_index('SEGMENT_NAME')[
        'DORMANT_PERCENT_WITH_TRANSACTIONS'
    ].sort_values()
    dormant_percent = dormant_percent.rename(index={
        'Small and medium-sized enterprise': 'Small and medium-sized\nenterprise'
    })
    plot = dormant_percent.plot(
        kind='barh',
        title='Dormant customers by segment',
        color=DARK_BLUE,
        figsize=(9, 6)
    )
    plot.set_xlim(0, max(dormant_percent.max() * 1.15, 1))
    plot.set_xlabel('Dormant customers (% of customers with transactions)')
    plot.set_ylabel('Segment')
    plot.figure.tight_layout()
    chart_path = OUTPUT_FOLDER / 'dormant_customers_by_segment_personal_gap.png'
    plot.figure.savefig(chart_path)
    plt.close(plot.figure)
    return chart_path


def plot_money_flow_by_country(money_flow, filename, logarithmic=True, title=None):
    OUTPUT_FOLDER.mkdir(parents=True, exist_ok=True)
    amounts_in_millions = money_flow / 1_000_000
    positive_amounts = amounts_in_millions.values[amounts_in_millions.values > 0]
    displayed_values = amounts_in_millions.where(amounts_in_millions > 0)

    figure = plt.figure(figsize=(16, 12))
    grid = figure.add_gridspec(
        2, 3,
        width_ratios=[14, 3.5, 0.8],
        height_ratios=[14, 2.7],
        wspace=0.05,
        hspace=0.05
    )
    axis = figure.add_subplot(grid[0, 0])
    column_total_axis = figure.add_subplot(grid[1, 0])
    row_total_axis = figure.add_subplot(grid[0, 1], sharey=axis)
    colorbar_axis = figure.add_subplot(grid[0, 2])

    if logarithmic:
        color_scale = LogNorm(vmin=positive_amounts.min(), vmax=positive_amounts.max())
        color_label = 'Sum of transaction amounts (millions, log color scale)'
    else:
        color_scale = None
        color_label = 'Sum of transaction amounts (millions)'

    heatmap = axis.imshow(
        displayed_values,
        cmap='Blues',
        norm=color_scale,
        vmin=None if logarithmic else 0,
        vmax=None if logarithmic else positive_amounts.max(),
        aspect='auto'
    )
    axis.set_xticks(range(len(money_flow.columns)))
    axis.set_xticklabels(money_flow.columns, rotation=0, ha='center')
    axis.xaxis.tick_top()
    axis.xaxis.set_label_position('top')
    axis.set_yticks(range(len(money_flow.index)))
    axis.set_yticklabels(money_flow.index)
    axis.set_xlabel('Target country')
    axis.set_ylabel('Origin country')
    figure.suptitle(title or 'Money flow between countries', y=0.99)

    column_total_axis.set_ylim(0, 1)
    column_total_axis.set_xlim(-0.5, len(money_flow.columns) - 0.5)
    column_total_axis.set_yticks([])
    column_total_axis.set_xticks([])
    column_total_axis.text(
        0, 0.9, 'Incoming total by target country (millions)',
        ha='left', va='top', fontsize=9
    )
    for column_number, total in enumerate(money_flow.sum(axis=0)):
        column_total_axis.text(
            column_number, 0.25, f'{format_number(total / 1_000_000, 1)} mil',
            ha='center', va='center', rotation=90, fontsize=10
        )
    for spine in column_total_axis.spines.values():
        spine.set_visible(False)

    row_total_axis.set_xlim(0, 1)
    row_total_axis.set_xticks([])
    row_total_axis.tick_params(axis='y', left=False, labelleft=False)
    row_total_axis.set_title('Outgoing total\n(millions)')
    for row_number, total in enumerate(money_flow.sum(axis=1)):
        row_total_axis.text(
            0.05, row_number, f'{format_number(total / 1_000_000, 1)} mil',
            ha='left', va='center', fontsize=10
        )
    for spine in row_total_axis.spines.values():
        spine.set_visible(False)

    colorbar = figure.colorbar(heatmap, cax=colorbar_axis)
    colorbar.set_label(color_label)
    figure.subplots_adjust(top=0.94, bottom=0.16, left=0.08, right=0.93)

    chart_path = OUTPUT_FOLDER / filename
    figure.savefig(chart_path)
    plt.close(figure)
    return chart_path


def plot_domestic_international_by_segment(summary):
    OUTPUT_FOLDER.mkdir(parents=True, exist_ok=True)
    summary = summary.sort_values('DOMESTIC_PERCENT')
    summary = summary.rename(index={
        'Small and medium-sized enterprise': 'Small and medium-sized\nenterprise'
    })

    plot = summary[['DOMESTIC_PERCENT', 'INTERNATIONAL_PERCENT']].plot(
        kind='barh',
        stacked=True,
        color=['#1F4E79', '#8FAADC'],
        figsize=(10, 7),
        title='Domestic and international transactions by segment'
    )
    plot.set_xlim(0, 100)
    plot.set_xlabel('Share of transactions (%)')
    plot.set_ylabel('Segment')
    plot.legend(
        ['Domestic (CZ to CZ)', 'International'],
        loc='upper center',
        bbox_to_anchor=(0.5, -0.12),
        ncol=2
    )
    plot.figure.subplots_adjust(bottom=0.2)
    plot.figure.tight_layout()

    chart_path = OUTPUT_FOLDER / 'domestic_international_by_segment.png'
    plot.figure.savefig(chart_path)
    plt.close(plot.figure)
    return chart_path


# Numbers are printed by the analysis scripts, here only the saved charts
def main():
    customer_df = load_customer_data()
    transaction_df = load_transaction_data()
    chart_paths = []

    average_amount = average_transaction_by_segment(customer_df, transaction_df)
    plot_average_transaction_by_segment(average_amount)
    chart_paths.append(OUTPUT_FOLDER / 'average_transaction_by_segment.png')

    monthly_turnover = average_monthly_turnover_by_segment(customer_df, transaction_df)
    chart_paths += plot_average_monthly_turnover_by_segment(monthly_turnover)

    transaction_amounts = transaction_amount_distribution_by_segment(
        customer_df, transaction_df
    )
    chart_paths += plot_transaction_amount_distribution_by_segment(transaction_amounts)

    top_customers = top_five_transactions_by_risk(customer_df, transaction_df)
    chart_paths += plot_top_five_by_risk(top_customers)

    dormancy_summary, customer_status = dormant_customers_by_segment(
        customer_df, transaction_df
    )
    chart_paths.append(plot_days_since_transaction(customer_status))
    chart_paths.append(plot_dormant_customers_by_segment(dormancy_summary))

    money_flow = money_flow_by_country(transaction_df)
    chart_paths.append(plot_money_flow_by_country(
        money_flow, 'money_flow_between_countries.png', logarithmic=True
    ))

    money_flow_without_czech = money_flow_by_country(
        transaction_df, include_czech=False, sort_by_amount=False
    )
    chart_paths.append(plot_money_flow_by_country(
        money_flow_without_czech,
        'money_flow_without_czech_alphabetical.png',
        logarithmic=False,
        title='Money flow between countries, excluding Czech Republic'
    ))

    domestic_international = domestic_international_by_segment(
        customer_df, transaction_df
    )
    chart_paths.append(plot_domestic_international_by_segment(domestic_international))

    for chart_path in chart_paths:
        print(f'Chart saved to {chart_path}')


if __name__ == '__main__':
    main()
