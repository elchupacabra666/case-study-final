from pathlib import Path
import sys

import matplotlib.pyplot as plt

PROJECT_FOLDER = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_FOLDER))

from analysis.customer import customer_percentages
from utils.io import load_customer_data


OUTPUT_FOLDER = PROJECT_FOLDER / 'outputs/figures'
DARK_BLUE = '#1F4E79'


def plot_customer_percentages(risk_percentages, segment_percentages, segment_risk):
    OUTPUT_FOLDER.mkdir(parents=True, exist_ok=True)

    plot = risk_percentages.plot(
        kind='bar', title='Customers by risk level (%)', color=DARK_BLUE
    )
    plot.set_ylabel('Customers (%)')
    plot.set_xlabel('Risk level')
    plot.tick_params(axis='x', labelrotation=0)
    plot.figure.tight_layout()
    plot.figure.savefig(OUTPUT_FOLDER / 'customers_by_risk_level.png', dpi=180)
    plt.close(plot.figure)

    segment_percentages = segment_percentages.rename(index={
        'Small and medium-sized enterprise': 'Small and medium-sized\nenterprise'
    })
    segment_percentages.sort_values().plot(
        kind='barh', title='Customers by segment (%)', color=DARK_BLUE
    )
    plt.ylabel('Segment')
    plt.xlabel('Customers (%)')
    plt.tight_layout()
    plt.savefig(OUTPUT_FOLDER / 'customers_by_segment.png', dpi=180)
    plt.close()

    high_risk_percentages = segment_risk['HIGH_RISK_PERCENT'].rename(index={
        'Small and medium-sized enterprise': 'Small and medium-sized\nenterprise'
    })
    high_risk_percentages.sort_values().plot(
        kind='barh', title='High-risk customers within each segment (%)', color=DARK_BLUE
    )
    plt.ylabel('Segment')
    plt.xlabel('High-risk customers (%)')
    plt.tight_layout()
    plt.savefig(OUTPUT_FOLDER / 'high_risk_by_segment.png', dpi=180)
    plt.close()


# Numbers are printed by analysis/customer.py, here only the saved charts
if __name__ == '__main__':
    customer_df = load_customer_data()
    risk_percentages, segment_percentages, segment_risk = customer_percentages(customer_df)

    plot_customer_percentages(risk_percentages, segment_percentages, segment_risk)
    for chart_name in ['customers_by_risk_level.png', 'customers_by_segment.png', 'high_risk_by_segment.png']:
        print(f'Chart saved to {OUTPUT_FOLDER / chart_name}')
