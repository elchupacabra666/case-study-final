import pandas as pd


# 1234567.891 -> '1 234 567.89'
def format_number(value, decimals=2):
    if pd.isna(value):
        return '-'
    return f'{value:,.{decimals}f}'.replace(',', ' ')


# Prints a table (DataFrame or Series) with numbers as 1 234 567.89
# decimals can be one number for all columns or a dict, e.g. {'RHO': 3}
# whole-number columns are always printed without decimals
# formatters = own format for some columns, e.g. {'P_VALUE': format_p_value}
def print_table(table, decimals=2, index=True, formatters=None):
    # work on a copy, so the original table keeps its numbers
    if isinstance(table, pd.Series):
        table = table.to_frame()
    else:
        table = table.copy()

    for column in table.columns:
        values = table[column]

        # own format for this column
        if formatters and column in formatters:
            table[column] = values.apply(formatters[column])

        # True / False stays as it is
        elif pd.api.types.is_bool_dtype(values):
            continue

        # whole numbers without decimals
        elif pd.api.types.is_integer_dtype(values):
            table[column] = values.apply(format_number, args=(0,))

        elif pd.api.types.is_float_dtype(values):
            if isinstance(decimals, dict):
                column_decimals = decimals.get(column, 2)
            else:
                column_decimals = decimals
            table[column] = values.apply(format_number, args=(column_decimals,))

    print(table.to_string(index=index))


# Chart axis with numbers as 1 000 000 instead of 1000000 or 1e6
# which = 'x' or 'y'
def format_chart_axis(axis, which='y'):
    from matplotlib.ticker import FuncFormatter

    formatter = FuncFormatter(lambda value, position: format_number(value, 0))
    if which == 'x':
        axis.xaxis.set_major_formatter(formatter)
    else:
        axis.yaxis.set_major_formatter(formatter)
