import pandas as pd
from pathlib import Path


PROJECT_FOLDER = Path(__file__).resolve().parents[1]
CORRECTED_CUSTOMER_PATH = PROJECT_FOLDER / 'data/corrected_customer.csv'
TRANSACTION_PATH = PROJECT_FOLDER / 'data/transaction.csv'


# reads a ; separated csv, data types and date columns are given by the caller
# (e.g. CUSTOMER_ID as str, so leading zeros stay)
def load_file(path, dtype=None, parse_dates=None, date_format=None, dayfirst=False):
    df = pd.read_csv(
        path,
        sep=';',
        encoding='utf-8',
        dtype=dtype,
        parse_dates=parse_dates,
        date_format=date_format,
        dayfirst=dayfirst
    )
    return df

def save_file(df, path, append=False):
    file_exists = Path(path).exists()
    df.to_csv(
        path,
        sep = ';',
        index = False,
        encoding = 'utf-8',
        date_format = '%Y-%m-%d',
        mode = 'a' if append else 'w',
        header = not append or not file_exists
    )


# corrected customer table made by main.py, used by all analysis scripts
def load_customer_data():
    return load_file(
        CORRECTED_CUSTOMER_PATH,
        dtype={'CUSTOMER_ID': str, 'RISK_RATING': 'Int64'},
        parse_dates=['REGISTER_DATE'],
        date_format='%Y-%m-%d'
    )


def load_transaction_data():
    return load_file(
        TRANSACTION_PATH,
        dtype={'CUSTOMER_ID': str},
        parse_dates=['TXN_DATE'],
        date_format='%Y-%m-%d'
    )
