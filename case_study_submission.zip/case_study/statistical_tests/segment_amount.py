from pathlib import Path
import sys

import pandas as pd
import scikit_posthocs as sp
from scipy import stats

PROJECT_FOLDER = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_FOLDER))

from utils.io import load_customer_data, load_transaction_data
from analysis.transactions import add_segment_to_transactions
from statistical_tests.helpers import SIGNIFICANCE_LEVEL, format_p_value
from utils.formatting import format_number, print_table


TABLE_FOLDER = PROJECT_FOLDER / 'outputs/tables'


# Put the amounts of each segment into a separate group
def amounts_by_segment(transactions, amount_column='AMOUNT'):
    groups = {}
    for segment in transactions['SEGMENT_NAME'].unique():
        segment_rows = transactions[transactions['SEGMENT_NAME'] == segment]
        groups[segment] = segment_rows[amount_column]

    return groups


# Levene's test checks if all segments have the same variance (spread).
# ANOVA assumes equal variances. If p < 0.05 the variances are different,
# so ANOVA is not reliable and Kruskal-Wallis is used instead.
def equal_variance_test(groups):
    statistic, p_value = stats.levene(*groups.values())

    return {'STATISTIC': statistic, 'P_VALUE': p_value}


# Kruskal-Wallis compares ranks instead of means, so it does not need
# normal data or equal variances
def kruskal_wallis_test(groups):
    group_list = list(groups.values())

    # H is large when the segments have very different average ranks
    h_statistic, p_value = stats.kruskal(*group_list)

    # Count all values in all groups (transactions or customers)
    observation_count = 0
    for group in group_list:
        observation_count += len(group)

    degrees_of_freedom = len(group_list) - 1

    # Epsilon squared = how much of the variation in ranks is explained by segment (0 to 1)
    epsilon_squared = h_statistic / (observation_count - 1)

    return {
        'H': h_statistic,
        'DEGREES_OF_FREEDOM': degrees_of_freedom,
        'P_VALUE': p_value,
        'EPSILON_SQUARED': epsilon_squared,
        'OBSERVATIONS': observation_count
    }


def effect_size_label(epsilon_squared):
    if epsilon_squared < 0.01:
        return 'negligible'
    elif epsilon_squared < 0.06:
        return 'small'
    elif epsilon_squared < 0.14:
        return 'medium'
    return 'large'


# Dunn's test compares every pair of segments.
# Holm correction is used because we run 36 tests at once.
def pairwise_segment_test(transactions, amount_column='AMOUNT'):
    p_values = sp.posthoc_dunn(
        transactions,
        val_col=amount_column,
        group_col='SEGMENT_NAME',
        p_adjust='holm'
    )

    # Turn the matrix into one row per pair of segments
    segments = p_values.index.tolist()
    pair_rows = []
    for first_index, first_segment in enumerate(segments):
        for second_segment in segments[first_index + 1:]:
            p_value = p_values.loc[first_segment, second_segment]
            pair_rows.append({
                'SEGMENT_1': first_segment,
                'SEGMENT_2': second_segment,
                'P_VALUE_HOLM': p_value,
                'SIGNIFICANT': p_value < SIGNIFICANCE_LEVEL
            })

    return p_values, pd.DataFrame(pair_rows)


# Transactions of the same customer are not independent, so the test is repeated
# with one value per customer (median transaction amount)
def median_amount_per_customer(transactions):
    customer_amounts = transactions.groupby(
        ['CUSTOMER_ID', 'SEGMENT_NAME']
    )['AMOUNT'].median().reset_index(name='MEDIAN_AMOUNT')

    return customer_amounts


def segment_amount_relationship(customer_df, transaction_df):
    transactions = add_segment_to_transactions(customer_df, transaction_df)
    groups = amounts_by_segment(transactions)

    variance_result = equal_variance_test(groups)
    kruskal_result = kruskal_wallis_test(groups)
    p_values, pairs = pairwise_segment_test(transactions)

    customer_amounts = median_amount_per_customer(transactions)
    customer_groups = amounts_by_segment(customer_amounts, amount_column='MEDIAN_AMOUNT')
    customer_kruskal_result = kruskal_wallis_test(customer_groups)

    # Median and average rank of each segment, to show which segments are higher
    transactions['AMOUNT_RANK'] = transactions['AMOUNT'].rank()
    segment_summary = transactions.groupby('SEGMENT_NAME').agg(
        TRANSACTIONS=('AMOUNT', 'size'),
        MEDIAN_AMOUNT=('AMOUNT', 'median'),
        AVERAGE_RANK=('AMOUNT_RANK', 'mean')
    ).sort_values('AVERAGE_RANK')

    return {
        'segment_summary': segment_summary,
        'variance': variance_result,
        'kruskal': kruskal_result,
        'pairwise_p_values': p_values,
        'pairs': pairs,
        'customer_kruskal': customer_kruskal_result
    }


def print_kruskal_result(result):
    print(f"H = {format_number(result['H'])}, df = {result['DEGREES_OF_FREEDOM']}, "
          f"p {format_p_value(result['P_VALUE'])}, n = {format_number(result['OBSERVATIONS'], 0)}")
    print(f"Epsilon squared = {result['EPSILON_SQUARED']:.3f} "
          f"({effect_size_label(result['EPSILON_SQUARED'])} effect)")


def main():
    customer_df = load_customer_data()
    transaction_df = load_transaction_data()

    results = segment_amount_relationship(customer_df, transaction_df)

    print('Transaction amount by segment (sorted by average rank):')
    print_table(results['segment_summary'])

    print("\nLevene's test for equal variances:")
    print(f"statistic = {format_number(results['variance']['STATISTIC'])}, "
          f"p {format_p_value(results['variance']['P_VALUE'])}")
    if results['variance']['P_VALUE'] < SIGNIFICANCE_LEVEL:
        print('Variances are not equal -> ANOVA is not suitable, using Kruskal-Wallis.')

    print('\nKruskal-Wallis test (one row per transaction):')
    print_kruskal_result(results['kruskal'])

    print('\nKruskal-Wallis test (one row per customer, median amount):')
    print_kruskal_result(results['customer_kruskal'])

    pairs = results['pairs']
    not_significant = pairs[~pairs['SIGNIFICANT']]
    print(f"\nDunn's test (Holm correction): {pairs['SIGNIFICANT'].sum()} of "
          f"{len(pairs)} segment pairs differ significantly.")
    if len(not_significant) > 0:
        print('Pairs without significant difference:')
        print_table(not_significant, index=False, formatters={'P_VALUE_HOLM': format_p_value})

    TABLE_FOLDER.mkdir(parents=True, exist_ok=True)
    table_path = TABLE_FOLDER / 'segment_amount_dunn_test.csv'
    pairs.to_csv(table_path, sep=';', index=False)
    print(f'\nTable saved to {table_path}')


if __name__ == '__main__':
    main()
