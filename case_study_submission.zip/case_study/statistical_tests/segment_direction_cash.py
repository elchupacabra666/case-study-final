from pathlib import Path
import sys

import pandas as pd
from scipy import stats

PROJECT_FOLDER = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_FOLDER))

from utils.io import load_customer_data, load_transaction_data
from analysis.transactions import add_segment_to_transactions
from statistical_tests.helpers import SIGNIFICANCE_LEVEL, format_p_value, holm_correction
from utils.formatting import format_number, print_table


TABLE_FOLDER = PROJECT_FOLDER / 'outputs/tables'


# Count transactions for each combination of segment and category (e.g. credit / debit)
def contingency_table(transactions, column):
    table = pd.crosstab(transactions['SEGMENT_NAME'], transactions[column])

    return table


# Chi-square test needs expected count of at least 5 in every cell
def check_expected_counts(expected):
    smallest_expected = expected.min().min()
    cells_below_five = (expected < 5).sum().sum()

    return smallest_expected, cells_below_five


# Chi-square test compares real counts with counts we would expect
# if segment and category were independent
def chi_square_test(table):
    chi_square, p_value, degrees_of_freedom, expected = stats.chi2_contingency(table)
    expected = pd.DataFrame(expected, index=table.index, columns=table.columns)

    observation_count = table.values.sum()
    smaller_dimension = min(table.shape)

    # Cramer's V = strength of association (0 to 1), does not grow with sample size
    cramers_v = (chi_square / (observation_count * (smaller_dimension - 1))) ** 0.5

    return {
        'CHI_SQUARE': chi_square,
        'DEGREES_OF_FREEDOM': degrees_of_freedom,
        'P_VALUE': p_value,
        'CRAMERS_V': cramers_v,
        'OBSERVATIONS': observation_count,
        'EXPECTED': expected
    }


def cramers_v_label(cramers_v):
    if cramers_v < 0.1:
        return 'negligible'
    elif cramers_v < 0.3:
        return 'weak'
    elif cramers_v < 0.5:
        return 'moderate'
    return 'strong'


# Adjusted residual shows how far one cell is from the expected count.
# It works like a z-score: around 0 = as expected, above 1.96 or below -1.96 = unusual.
# The table has only two columns, so the residual for the second category is the same
# number with opposite sign. That is why only one category is checked.
def segment_residuals(table, expected, category):
    observation_count = table.values.sum()
    category_total = table[category].sum()
    overall_percent = category_total / observation_count * 100
    summary_rows = []

    for segment in table.index:
        segment_total = table.loc[segment].sum()
        observed = table.loc[segment, category]
        expected_count = expected.loc[segment, category]

        segment_share = segment_total / observation_count
        category_share = category_total / observation_count
        adjusted_residual = (observed - expected_count) / (
            expected_count * (1 - segment_share) * (1 - category_share)
        ) ** 0.5

        segment_percent = observed / segment_total * 100
        summary_rows.append({
            'SEGMENT_NAME': segment,
            'TRANSACTIONS': segment_total,
            'PERCENT': segment_percent,
            'DIFFERENCE_FROM_OVERALL': segment_percent - overall_percent,
            'ADJUSTED_RESIDUAL': adjusted_residual,
            'P_VALUE': 2 * stats.norm.sf(abs(adjusted_residual))
        })

    summary = pd.DataFrame(summary_rows)

    # 9 segments are checked at once, so p-values are adjusted with Holm correction
    summary['P_VALUE_HOLM'] = holm_correction(summary['P_VALUE'].tolist())

    results = []
    for _, row in summary.iterrows():
        if row['P_VALUE_HOLM'] >= SIGNIFICANCE_LEVEL:
            results.append('as expected')
        elif row['ADJUSTED_RESIDUAL'] > 0:
            results.append('more than expected')
        else:
            results.append('less than expected')
    summary['RESULT'] = results

    return summary.sort_values('PERCENT', ascending=False), overall_percent


def segment_category_association(customer_df, transaction_df, column, category):
    transactions = add_segment_to_transactions(customer_df, transaction_df)

    table = contingency_table(transactions, column)
    test_result = chi_square_test(table)
    smallest_expected, cells_below_five = check_expected_counts(test_result['EXPECTED'])
    residuals, overall_percent = segment_residuals(table, test_result['EXPECTED'], category)

    return {
        'table': table,
        'test': test_result,
        'smallest_expected': smallest_expected,
        'cells_below_five': cells_below_five,
        'residuals': residuals,
        'overall_percent': overall_percent
    }


def print_association_result(results, category_name):
    test_result = results['test']

    print(f"\nSmallest expected count: {format_number(results['smallest_expected'], 0)}, "
          f"cells below 5: {results['cells_below_five']}")
    if results['cells_below_five'] == 0:
        print('All expected counts are at least 5 -> chi-square test can be used.')

    print('\nChi-square test of independence:')
    print(f"chi-square = {format_number(test_result['CHI_SQUARE'])}, "
          f"df = {test_result['DEGREES_OF_FREEDOM']}, "
          f"p {format_p_value(test_result['P_VALUE'])}, "
          f"n = {format_number(test_result['OBSERVATIONS'], 0)}")
    print(f"Cramer's V = {test_result['CRAMERS_V']:.3f} "
          f"({cramers_v_label(test_result['CRAMERS_V'])} association)")

    print(f"\nShare of {category_name} transactions by segment "
          f"(overall {results['overall_percent']:.2f}%):")
    print_table(results['residuals'][[
        'SEGMENT_NAME', 'TRANSACTIONS', 'PERCENT', 'DIFFERENCE_FROM_OVERALL',
        'ADJUSTED_RESIDUAL', 'RESULT'
    ]], index=False)


def main():
    customer_df = load_customer_data()
    transaction_df = load_transaction_data()
    TABLE_FOLDER.mkdir(parents=True, exist_ok=True)

    # Question 1: segment and transaction direction (C = credit, D = debit)
    direction = segment_category_association(
        customer_df, transaction_df, 'CREDIT_DEBIT', 'C'
    )
    print('Transactions by segment and direction:')
    print_table(direction['table'])
    print_association_result(direction, 'credit')

    table_path = TABLE_FOLDER / 'segment_credit_debit_chi_square.csv'
    direction['residuals'].to_csv(table_path, sep=';', index=False)
    print(f'\nTable saved to {table_path}')

    # Question 2: segment and transaction type (C = cash, NC = non-cash)
    cash = segment_category_association(
        customer_df, transaction_df, 'CASH_NONCASH', 'C'
    )
    print('\nTransactions by segment and cash flag:')
    print_table(cash['table'])
    print_association_result(cash, 'cash')

    table_path = TABLE_FOLDER / 'segment_cash_chi_square.csv'
    cash['residuals'].to_csv(table_path, sep=';', index=False)
    print(f'\nTable saved to {table_path}')


if __name__ == '__main__':
    main()
