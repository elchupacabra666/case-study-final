from pathlib import Path
import sys

import pandas as pd
from scipy import stats

PROJECT_FOLDER = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_FOLDER))

from utils.io import load_customer_data, load_transaction_data
from statistical_tests.helpers import SIGNIFICANCE_LEVEL, format_p_value, holm_correction
from utils.formatting import format_number, print_table


TABLE_FOLDER = PROJECT_FOLDER / 'outputs/tables'


# Merge RISK_RATING and SEGMENT_NAME into transactions
def add_risk_to_transactions(customer_df, transaction_df):
    customer_info = customer_df[['CUSTOMER_ID', 'RISK_RATING', 'SEGMENT_NAME']]

    transactions_with_risk = pd.merge(
        transaction_df,
        customer_info,
        on='CUSTOMER_ID',
        how='left'
    )

    return transactions_with_risk


# Spearman correlation works with ranks, so it fits risk rating (1 < 2 < 3 is an order,
# but High is not exactly "3 times" Low) and skewed amounts.
# Rho goes from -1 to 1. Negative rho = higher risk goes with smaller amounts.
def spearman_correlation(risk_values, amounts):
    rho, p_value = stats.spearmanr(risk_values, amounts)

    return {
        'RHO': rho,
        'P_VALUE': p_value,
        'OBSERVATIONS': len(amounts)
    }


def correlation_strength_label(rho):
    size = abs(rho)
    if size < 0.1:
        return 'negligible'
    elif size < 0.3:
        return 'weak'
    elif size < 0.5:
        return 'moderate'
    return 'strong'


# Same robustness check as for segments: one value per customer
def median_amount_per_customer(transactions):
    customer_amounts = transactions.groupby(
        ['CUSTOMER_ID', 'RISK_RATING']
    )['AMOUNT'].median().reset_index(name='MEDIAN_AMOUNT')

    return customer_amounts


# Segments have very different amounts, so the overall correlation could come just
# from which segments are more risky. Here the correlation is calculated
# inside each segment separately.
def correlation_within_segments(transactions):
    summary_rows = []

    for segment in transactions['SEGMENT_NAME'].unique():
        segment_transactions = transactions[
            transactions['SEGMENT_NAME'] == segment
        ]
        result = spearman_correlation(
            segment_transactions['RISK_RATING'],
            segment_transactions['AMOUNT']
        )

        summary_rows.append({
            'SEGMENT_NAME': segment,
            'TRANSACTIONS': result['OBSERVATIONS'],
            'RHO': result['RHO'],
            'P_VALUE': result['P_VALUE']
        })

    summary = pd.DataFrame(summary_rows)

    # 9 tests at once, so p-values are adjusted with Holm correction
    summary['P_VALUE_HOLM'] = holm_correction(summary['P_VALUE'].tolist())
    summary['SIGNIFICANT'] = summary['P_VALUE_HOLM'] < SIGNIFICANCE_LEVEL

    return summary.sort_values('SEGMENT_NAME')


# Percentage of transactions from each segment within each risk level
def segment_mix_by_risk(transactions):
    segment_mix = pd.crosstab(
        transactions['SEGMENT_NAME'],
        transactions['RISK_RATING'],
        normalize='columns'
    ) * 100

    return segment_mix


def risk_amount_relationship(customer_df, transaction_df):
    transactions = add_risk_to_transactions(customer_df, transaction_df)

    overall_result = spearman_correlation(
        transactions['RISK_RATING'], transactions['AMOUNT']
    )

    customer_amounts = median_amount_per_customer(transactions)
    customer_result = spearman_correlation(
        customer_amounts['RISK_RATING'], customer_amounts['MEDIAN_AMOUNT']
    )

    within_segments = correlation_within_segments(transactions)
    segment_mix = segment_mix_by_risk(transactions)

    risk_summary = transactions.groupby('RISK_RATING').agg(
        TRANSACTIONS=('AMOUNT', 'size'),
        MEDIAN_AMOUNT=('AMOUNT', 'median'),
        AVERAGE_AMOUNT=('AMOUNT', 'mean')
    )

    return {
        'risk_summary': risk_summary,
        'overall': overall_result,
        'customer': customer_result,
        'within_segments': within_segments,
        'segment_mix': segment_mix
    }


def print_correlation_result(result):
    print(f"rho = {result['RHO']:.3f} ({correlation_strength_label(result['RHO'])}), "
          f"p {format_p_value(result['P_VALUE'])}, n = {format_number(result['OBSERVATIONS'], 0)}")


def main():
    customer_df = load_customer_data()
    transaction_df = load_transaction_data()

    results = risk_amount_relationship(customer_df, transaction_df)

    print('Transaction amount by risk rating:')
    print_table(results['risk_summary'])

    print('\nSpearman correlation, risk rating vs amount (one row per transaction):')
    print_correlation_result(results['overall'])

    print('\nSpearman correlation, risk rating vs amount (one row per customer, median amount):')
    print_correlation_result(results['customer'])

    print('\nShare of transactions from each segment within each risk rating (%):')
    print_table(results['segment_mix'], decimals=1)

    within_segments = results['within_segments']
    print('\nSpearman correlation inside each segment (Holm correction):')
    print_table(within_segments, decimals={'RHO': 3}, index=False, formatters={
        'P_VALUE': format_p_value, 'P_VALUE_HOLM': format_p_value
    })
    print(f"{within_segments['SIGNIFICANT'].sum()} of {len(within_segments)} "
          f"segments have a significant correlation.")

    TABLE_FOLDER.mkdir(parents=True, exist_ok=True)
    table_path = TABLE_FOLDER / 'risk_amount_correlation_by_segment.csv'
    within_segments.to_csv(table_path, sep=';', index=False)
    print(f'\nTable saved to {table_path}')


if __name__ == '__main__':
    main()
