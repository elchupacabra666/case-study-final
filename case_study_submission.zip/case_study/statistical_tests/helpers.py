SIGNIFICANCE_LEVEL = 0.05


def format_p_value(p_value):
    if p_value < 0.001:
        return '< 0.001'
    return f'{p_value:.3f}'


# Holm correction for running many tests at once.
# Smallest p-value is multiplied by the number of tests, the second smallest
# by (number of tests - 1) and so on. Adjusted values can never go down.
def holm_correction(p_values):
    test_count = len(p_values)
    order = sorted(range(test_count), key=lambda index: p_values[index])
    adjusted = [0] * test_count
    highest_so_far = 0

    for position, index in enumerate(order):
        adjusted_value = min(1, p_values[index] * (test_count - position))
        highest_so_far = max(highest_so_far, adjusted_value)
        adjusted[index] = highest_so_far

    return adjusted
