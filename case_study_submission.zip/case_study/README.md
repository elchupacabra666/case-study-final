# Financial Crime Data Analysis - case study

## Setup

```
pip install -r requirements.txt
```

The `data` folder needs `customer.csv` and `transaction.csv` (original files from the case study zip)
and `basel_aml_index_2025.csv` (country risk scores for task 4).

## How to run

Run everything from the project folder. `main.py` has to run first, the other scripts use its output.

| Task | Command | Output |
|---|---|---|
| 1 Data quality | `python main.py` | `data/corrected_customer.csv`, `data/error_rows.csv` |
| 2a Customers by risk and segment | `python analysis/customer.py` | printed |
| 2b-2h Transactions | `python analysis/transactions.py` | printed |
| 3a Segment and amount | `python statistical_tests/segment_amount.py` | `outputs/tables/segment_amount_dunn_test.csv` |
| 3a Risk and amount | `python statistical_tests/risk_amount.py` | `outputs/tables/risk_amount_correlation_by_segment.csv` |
| 3b Segment, direction and cash | `python statistical_tests/segment_direction_cash.py` | `outputs/tables/segment_*_chi_square.csv` |
| 4a Country risk | `python analysis/country_risk.py` | `outputs/tables/customer_country_risk.csv` |
| 5a AML scenario | `python analysis/aml_scenario.py` | `outputs/tables/aml_alerts.csv` |
| Charts for 2a | `python visualizations/customer.py` | `outputs/figures/` |
| Charts for 2b-2h | `python visualizations/transactions.py` | `outputs/figures/` |

## Folder structure

```
main.py                 task 1, runs the data cleaning
data_quality.py         data cleaning steps and final check
analysis/               tasks 2, 4 and 5
statistical_tests/      task 3
visualizations/         charts
utils/                  loading/saving csv files, number formatting
```

## Main decisions

- Customer table: rows missing both segment code and name (or both risk values) and the customer ID
  that appears twice with different data are removed and saved to `data/error_rows.csv`.
- Typos: only 1 wrong character is fixed (as the task says). Segment codes are not fuzzy fixed,
  a wrong code is filled again from the segment name.
- Missing register dates are filled with the median, as the task asks.
- Domestic transaction = CZ to CZ. CZ is the home country (same as in the AML scenario).
- Turnover per month is averaged over active customers (at least one transaction).
  89% of customers have no transactions in 2022, they are covered in the dormant customers part.
- Country risk: Basel AML Index 2025. Russia is not in the public index, it gets 10 (maximum),
  because the EU lists it as a high-risk third country.
