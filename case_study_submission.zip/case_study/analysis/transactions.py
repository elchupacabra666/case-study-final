from pathlib import Path
import sys

import pandas as pd

PROJECT_FOLDER = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_FOLDER))

from utils.io import load_customer_data, load_transaction_data
from utils.formatting import format_number, print_table


# Merge SEGMENT_NAME into transactions
def add_segment_to_transactions(customer_df, transaction_df):
    customer_segments = customer_df[['CUSTOMER_ID', 'SEGMENT_NAME']]

    transactions_with_segment = pd.merge(
        transaction_df,
        customer_segments,
        on='CUSTOMER_ID',
        how='left'
    )

    return transactions_with_segment

# Average transaction amount in each segment
def average_transaction_by_segment(customer_df, transaction_df):
    transactions_with_segment = add_segment_to_transactions(customer_df, transaction_df)
    average_amount = transactions_with_segment.groupby('SEGMENT_NAME')['AMOUNT'].mean()

    return average_amount


def transaction_amount_distribution_by_segment(customer_df, transaction_df):
    transactions_with_segment = add_segment_to_transactions(customer_df, transaction_df)

    return transactions_with_segment[['SEGMENT_NAME', 'AMOUNT']]


def average_monthly_turnover_by_segment(customer_df, transaction_df):
    transactions = add_segment_to_transactions(customer_df, transaction_df)
    transactions['MONTH'] = transactions['TXN_DATE'].dt.to_period('M')

    # First add up each customer's transactions within each month.
    customer_monthly_turnover = transactions.groupby(
        ['CUSTOMER_ID', 'SEGMENT_NAME', 'MONTH']
    )['AMOUNT'].sum().reset_index(name='TURNOVER')

    # Then add up customer turnover within each segment and month.
    segment_monthly_turnover = customer_monthly_turnover.groupby(
        ['SEGMENT_NAME', 'MONTH']
    )['TURNOVER'].sum().reset_index()

    # Find how many active customers are in each segment.
    # Active customer = at least one transaction in the data.
    segment_monthly_turnover['CUSTOMER_COUNT'] = 0
    for segment in customer_df['SEGMENT_NAME'].unique():
        customers_in_segment = transactions[
            transactions['SEGMENT_NAME'] == segment
        ]
        customer_count = customers_in_segment['CUSTOMER_ID'].nunique()

        rows_for_segment = segment_monthly_turnover['SEGMENT_NAME'] == segment
        segment_monthly_turnover.loc[rows_for_segment, 'CUSTOMER_COUNT'] = customer_count

    # Divide by active customers only. Customers with no transactions are left out
    # (they are covered in dormant customers). An active customer with no transactions
    # in some month still counts as zero for that month.
    segment_monthly_turnover['AVERAGE_TURNOVER'] = (
        segment_monthly_turnover['TURNOVER'] / segment_monthly_turnover['CUSTOMER_COUNT']
    )

    return segment_monthly_turnover


def money_flow_by_country(transaction_df, include_czech=True, sort_by_amount=True):
    money_flow = transaction_df.groupby(
        ['ORIGIN_COUNTRY', 'TARGET_COUNTRY']
    )['AMOUNT'].sum().unstack(fill_value=0)

    if not include_czech:
        money_flow = money_flow.drop(index='CZ', columns='CZ')

    if sort_by_amount:
        # Sort origins by total outgoing amount and targets by total incoming amount.
        origin_order = money_flow.sum(axis=1).sort_values(ascending=False).index
        target_order = money_flow.sum(axis=0).sort_values(ascending=False).index
        money_flow = money_flow.loc[origin_order, target_order]
    else:
        money_flow = money_flow.sort_index().sort_index(axis=1)

    return money_flow


def domestic_international_by_segment(customer_df, transaction_df):
    transactions = add_segment_to_transactions(customer_df, transaction_df)
    summary_rows = []

    for segment in transactions['SEGMENT_NAME'].unique():
        segment_transactions = transactions[
            transactions['SEGMENT_NAME'] == segment
        ]
        # Domestic = CZ to CZ only. CZ is the home country, like in the AML scenario.
        # Transactions like DE to DE count as international.
        domestic_count = (
            (segment_transactions['ORIGIN_COUNTRY'] == 'CZ')
            & (segment_transactions['TARGET_COUNTRY'] == 'CZ')
        ).sum()
        international_count = len(segment_transactions) - domestic_count
        total_transactions = len(segment_transactions)

        summary_rows.append({
            'SEGMENT_NAME': segment,
            'DOMESTIC': domestic_count,
            'INTERNATIONAL': international_count,
            'DOMESTIC_PERCENT': domestic_count / total_transactions * 100,
            'INTERNATIONAL_PERCENT': international_count / total_transactions * 100
        })

    return pd.DataFrame(summary_rows).set_index('SEGMENT_NAME')


def top_five_transactions_by_risk(customer_df, transaction_df):

    # merge RISK_RATING_NAME into transactions
    customer_risk = customer_df[['CUSTOMER_ID', 'RISK_RATING_NAME']]
    transactions_with_risk = pd.merge(
        transaction_df,
        customer_risk,
        on='CUSTOMER_ID',
        how='left'
    )

    top_customers = {}
    for risk in ['Low', 'Medium', 'High']:
        risk_transactions = transactions_with_risk[
            transactions_with_risk['RISK_RATING_NAME'] == risk
        ]
        highest_transaction_per_customer = risk_transactions.loc[
            risk_transactions.groupby('CUSTOMER_ID')['AMOUNT'].idxmax()
        ]
        top_customers[risk] = highest_transaction_per_customer.sort_values(
            'AMOUNT', ascending=False
        ).head(5)

    return top_customers


def dormant_customers_by_segment(customer_df, transaction_df):
    transactions = add_segment_to_transactions(customer_df, transaction_df)
    as_of_date = transactions['TXN_DATE'].max()

    transactions = transactions.sort_values(['CUSTOMER_ID', 'TXN_DATE'])
    transactions['GAP_DAYS'] = transactions.groupby('CUSTOMER_ID')['TXN_DATE'].diff().dt.days

    # Count each customer's transactions and find their last transaction date.
    transaction_count = transactions.groupby('CUSTOMER_ID').size()
    last_transaction = transactions.groupby('CUSTOMER_ID')['TXN_DATE'].max()
    personal_gap_95 = transactions.groupby('CUSTOMER_ID')['GAP_DAYS'].quantile(0.95)
    customer_activity = pd.DataFrame({
        'TRANSACTION_COUNT': transaction_count,
        'LAST_TRANSACTION': last_transaction,
        'PERSONAL_GAP_95': personal_gap_95
    })
    customer_status = customer_df[['CUSTOMER_ID', 'SEGMENT_NAME', 'REGISTER_DATE']].merge(
        customer_activity, on='CUSTOMER_ID', how='left'
    )
    customer_status['DAYS_SINCE_TXN'] = (
        as_of_date - customer_status['LAST_TRANSACTION']
    ).dt.total_seconds() / 86400

    # Decide each customer's status using their own usual transaction gaps.
    statuses = []
    limits = []
    for _, customer in customer_status.iterrows():
        if pd.isna(customer['TRANSACTION_COUNT']):
            status = 'never active'
            limit = None
        elif pd.isna(customer['PERSONAL_GAP_95']) or customer['TRANSACTION_COUNT'] < 3:
            status = 'insufficient history'
            limit = None
        else:
            limit = max(1, customer['PERSONAL_GAP_95'] * 3)
            days_since_registration = (as_of_date - customer['REGISTER_DATE']).days

            if days_since_registration < limit:
                status = 'new'
            elif customer['DAYS_SINCE_TXN'] > limit:
                status = 'dormant'
            else:
                status = 'active'

        statuses.append(status)
        limits.append(limit)

    customer_status['STATUS'] = statuses
    customer_status['DORMANT_LIMIT_DAYS'] = limits

    # Count each status in each segment.
    summary_rows = []
    for segment in customer_status['SEGMENT_NAME'].unique():
        segment_customers = customer_status[
            customer_status['SEGMENT_NAME'] == segment
        ]
        customers_with_transactions = segment_customers[
            segment_customers['TRANSACTION_COUNT'].notna()
        ]

        dormant_count = (segment_customers['STATUS'] == 'dormant').sum()
        new_count = (segment_customers['STATUS'] == 'new').sum()
        insufficient_history_count = (
            segment_customers['STATUS'] == 'insufficient history'
        ).sum()
        never_active_count = (segment_customers['STATUS'] == 'never active').sum()
        total_customers = len(segment_customers)
        transaction_customer_count = len(customers_with_transactions)

        summary_rows.append({
            'SEGMENT_NAME': segment,
            'DORMANT': dormant_count,
            'NEW': new_count,
            'INSUFFICIENT_HISTORY': insufficient_history_count,
            'NEVER_ACTIVE': never_active_count,
            'CUSTOMERS_WITH_TRANSACTIONS': transaction_customer_count,
            'CUSTOMERS': total_customers,
            'MEDIAN_DORMANT_LIMIT_DAYS': segment_customers[
                'DORMANT_LIMIT_DAYS'
            ].median(),
            'DORMANT_PERCENT_WITH_TRANSACTIONS': (
                dormant_count / transaction_customer_count * 100
                if transaction_customer_count else 0
            ),
            'DORMANT_PERCENT_ALL': dormant_count / total_customers * 100,
            'NEVER_ACTIVE_PERCENT': never_active_count / total_customers * 100
        })

    summary = pd.DataFrame(summary_rows)

    return summary, customer_status


def main():
    customer_df = load_customer_data()
    transaction_df = load_transaction_data()

    print('Transaction date range: '
          f"{transaction_df['TXN_DATE'].min().date()} to {transaction_df['TXN_DATE'].max().date()}")

    monthly_transactions = transaction_df.groupby(
        transaction_df['TXN_DATE'].dt.to_period('M')
    ).size()
    print('\nTransactions by month:')
    print_table(monthly_transactions.rename('TRANSACTIONS'))

    average_amount = average_transaction_by_segment(customer_df, transaction_df)
    print('\nAverage transaction amount by segment:')
    print_table(average_amount.rename('AVERAGE_AMOUNT').sort_values(ascending=False))

    # One average per segment is enough for the printout, month by month numbers are in the charts
    monthly_turnover = average_monthly_turnover_by_segment(customer_df, transaction_df)
    turnover_summary = monthly_turnover.groupby('SEGMENT_NAME').agg(
        ACTIVE_CUSTOMERS=('CUSTOMER_COUNT', 'first'),
        AVERAGE_MONTHLY_TURNOVER=('AVERAGE_TURNOVER', 'mean')
    ).sort_values('AVERAGE_MONTHLY_TURNOVER', ascending=False)
    print('\nAverage monthly turnover per active customer (average of the 12 months):')
    print_table(turnover_summary)

    money_flow = money_flow_by_country(transaction_df)

    # Turn the country matrix into one row per origin and target pair
    country_pairs = money_flow.stack().reset_index(name='AMOUNT')
    country_pairs = country_pairs.sort_values('AMOUNT', ascending=False)
    top_flows = country_pairs.head(10)

    print('\nTop 10 country pairs by total transaction amount (full table is in the heatmap):')
    print_table(top_flows, index=False)

    domestic_international = domestic_international_by_segment(
        customer_df, transaction_df
    )
    print('\nDomestic (CZ to CZ) and international transactions by segment:')
    print_table(
        domestic_international[['DOMESTIC', 'INTERNATIONAL', 'DOMESTIC_PERCENT']]
        .sort_values('DOMESTIC_PERCENT', ascending=False),
        decimals=1
    )

    top_customers = top_five_transactions_by_risk(customer_df, transaction_df)
    for risk, customers in top_customers.items():
        print(f'\nFive customers with the largest single transaction in {risk} risk:')
        print_table(customers[['CUSTOMER_ID', 'TXN_ID', 'TXN_DATE', 'AMOUNT']], index=False)

    dormancy, customer_status = dormant_customers_by_segment(customer_df, transaction_df)

    print('\nDays since last transaction (customers with transactions):')
    print_table(customer_status['DAYS_SINCE_TXN'].dropna().describe(
        percentiles=[0.5, 0.9, 0.95, 0.99]
    ).rename('DAYS'))

    never_active_count = (customer_status['STATUS'] == 'never active').sum()
    print(f"\nNever active: {format_number(never_active_count, 0)} of "
          f"{format_number(len(customer_status), 0)} customers "
          f"({never_active_count / len(customer_status) * 100:.1f}%)")

    print('\nDormant customers using 3 times their personal 95th-percentile gap:')
    dormancy_table = dormancy.set_index('SEGMENT_NAME')[[
        'CUSTOMERS', 'NEVER_ACTIVE', 'NEVER_ACTIVE_PERCENT', 'DORMANT',
        'DORMANT_PERCENT_WITH_TRANSACTIONS', 'MEDIAN_DORMANT_LIMIT_DAYS'
    ]].sort_values('NEVER_ACTIVE_PERCENT', ascending=False)
    # shorter column names, otherwise the table is too wide
    dormancy_table = dormancy_table.rename(columns={
        'NEVER_ACTIVE_PERCENT': 'NEVER_ACTIVE_%',
        'DORMANT_PERCENT_WITH_TRANSACTIONS': 'DORMANT_%_OF_ACTIVE',
        'MEDIAN_DORMANT_LIMIT_DAYS': 'MEDIAN_LIMIT_DAYS'
    })
    print_table(dormancy_table, decimals=1)
    print(f"New customers: {format_number(dormancy['NEW'].sum(), 0)}, "
          f"insufficient history: {format_number(dormancy['INSUFFICIENT_HISTORY'].sum(), 0)}")


if __name__ == '__main__':
    main()
