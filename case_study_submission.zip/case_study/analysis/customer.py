from pathlib import Path
import sys

import pandas as pd

PROJECT_FOLDER = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_FOLDER))

from utils.formatting import print_table
from utils.io import load_customer_data


def customer_percentages(customer_df):

    # What is the percentage of customers in each risk level?
    risk_values = customer_df['RISK_RATING_NAME']
    total_with_risk = len(risk_values)
    risk_percentages = {}

    for risk in ['Low', 'Medium', 'High']:
        risk_count = (risk_values == risk).sum()
        risk_percentages[risk] = risk_count / total_with_risk * 100
        

    # What is the percentage of customers in each segment?
    # What is the percentage of high-risk customers in each segment?
    segment_values = customer_df['SEGMENT_NAME']
    total_with_segment = len(segment_values)
    segment_percentages = {}
    segment_risk_results = []

    for segment in segment_values.unique():
        segment_rows = customer_df[customer_df['SEGMENT_NAME'] == segment]
        segment_count = len(segment_rows)
        high_risk_count = (
            segment_rows['RISK_RATING_NAME'] == 'High'
        ).sum()

        segment_percentages[segment] = (
            segment_count / total_with_segment * 100
        )

        segment_risk_results.append({
            'SEGMENT_NAME': segment,
            'CUSTOMERS': segment_count,
            'HIGH_RISK': high_risk_count,
            'HIGH_RISK_PERCENT': high_risk_count / segment_count * 100
        })

    segment_risk = pd.DataFrame(segment_risk_results).set_index('SEGMENT_NAME')

    return (
        pd.Series(risk_percentages),
        pd.Series(segment_percentages),
        segment_risk
    )


def main():
    customer_df = load_customer_data()
    risk_percentages, segment_percentages, segment_risk = customer_percentages(customer_df)

    print('Customers by risk level (%):')
    print_table(risk_percentages.rename('PERCENT'), decimals=1)

    print('\nCustomers by segment (%):')
    print_table(segment_percentages.rename('PERCENT').sort_values(ascending=False), decimals=1)

    print('\nHigh-risk customers within each segment:')
    print_table(segment_risk.sort_values('HIGH_RISK_PERCENT', ascending=False), decimals=1)


if __name__ == '__main__':
    main()
