from pathlib import Path
import sys

import pandas as pd

PROJECT_FOLDER = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_FOLDER))

import utils.io as io
from utils.io import load_customer_data, load_transaction_data
from utils.formatting import print_table


BASEL_PATH = PROJECT_FOLDER / 'data/basel_aml_index_2025.csv'
TABLE_FOLDER = PROJECT_FOLDER / 'outputs/tables'

# Basel AML Index 2025 (https://index.baselgovernance.org/ranking), score 0-10.
# Russia is not in the public index since 2023, because FATF suspended its membership.
# The EU added Russia to its list of high-risk third countries (Delegated Regulation 2026/46,
# which amends the list in Regulation 2016/1675, in force from 29 January 2026),
# so I give it the highest possible score.
# Note: transactions are from 2022, so this applies today's list to older data.
RUSSIA_SCORE = 10.0
EU_HIGH_RISK_COUNTRIES = ['RU']

# CZ is the home country (most transactions start there), so its risk is the baseline
# for the excess amount
HOME_COUNTRY = 'CZ'
TOP_N = 10


def load_country_scores():
    basel = io.load_file(BASEL_PATH)
    country_scores = dict(zip(basel['ISO_CODE'], basel['BASEL_SCORE']))

    country_scores['RU'] = RUSSIA_SCORE
    # transaction data uses UK instead of the ISO code GB
    country_scores['UK'] = country_scores['GB']

    return country_scores


def add_country_risk_to_transactions(transaction_df, country_scores):
    transactions = transaction_df.copy()
    transactions['ORIGIN_RISK'] = transactions['ORIGIN_COUNTRY'].map(country_scores)
    transactions['TARGET_RISK'] = transactions['TARGET_COUNTRY'].map(country_scores)

    # Stop if some country has no score, otherwise its transactions would quietly drop out
    all_countries = set(transactions['ORIGIN_COUNTRY']) | set(transactions['TARGET_COUNTRY'])
    missing = all_countries - set(country_scores)
    if missing:
        raise ValueError(f'No country risk score for: {sorted(missing)}')

    # Money in and money out both matter, so the riskier of the two countries counts
    transactions['TXN_RISK'] = transactions[['ORIGIN_RISK', 'TARGET_RISK']].max(axis=1)
    transactions['EU_HIGH_RISK'] = (
        transactions['ORIGIN_COUNTRY'].isin(EU_HIGH_RISK_COUNTRIES)
        | transactions['TARGET_COUNTRY'].isin(EU_HIGH_RISK_COUNTRIES)
    )
    transactions['EU_HIGH_RISK_AMOUNT'] = transactions['AMOUNT'].where(
        transactions['EU_HIGH_RISK'], 0
    )

    transactions['RISK_AMOUNT'] = transactions['AMOUNT'] * transactions['TXN_RISK']

    # Every country scores at least 3, so the plain risk amount mostly grows with turnover.
    # Here only the risk above the Czech score counts, so domestic payments add nothing.
    home_risk = country_scores[HOME_COUNTRY]
    transactions['EXCESS_RISK_AMOUNT'] = (
        transactions['AMOUNT'] * (transactions['TXN_RISK'] - home_risk).clip(lower=0)
    )

    return transactions


def customer_country_risk(customer_df, transaction_df):
    country_scores = load_country_scores()
    transactions = add_country_risk_to_transactions(transaction_df, country_scores)

    customer_risk = transactions.groupby('CUSTOMER_ID').agg(
        TRANSACTIONS=('TXN_ID', 'size'),
        TURNOVER=('AMOUNT', 'sum'),
        RISK_AMOUNT=('RISK_AMOUNT', 'sum'),
        EXCESS_RISK_AMOUNT=('EXCESS_RISK_AMOUNT', 'sum'),
        MAX_TXN_RISK=('TXN_RISK', 'max'),
        EU_HIGH_RISK_TRANSACTIONS=('EU_HIGH_RISK', 'sum'),
        EU_HIGH_RISK_AMOUNT=('EU_HIGH_RISK_AMOUNT', 'sum')
    ).reset_index()

    # Average country risk weighted by amount, stays on the 0-10 Basel scale.
    # Example: 10,000 CZ->CZ (3.82), 5,000 CZ->DE (4.97), 5,000 CZ->RU (10)
    # = (38,200 + 24,850 + 50,000) / 20,000 = 5.65
    customer_risk['AVERAGE_COUNTRY_RISK'] = (
        customer_risk['RISK_AMOUNT'] / customer_risk['TURNOVER']
    )
    customer_risk['EU_HIGH_RISK_PERCENT'] = (
        customer_risk['EU_HIGH_RISK_AMOUNT'] / customer_risk['TURNOVER'] * 100
    )

    # Rank 1 = riskiest
    customer_risk['RANK_AVERAGE_RISK'] = customer_risk['AVERAGE_COUNTRY_RISK'].rank(
        ascending=False, method='min'
    ).astype(int)
    customer_risk['RANK_EXCESS_AMOUNT'] = customer_risk['EXCESS_RISK_AMOUNT'].rank(
        ascending=False, method='min'
    ).astype(int)

    customer_info = customer_df[['CUSTOMER_ID', 'SEGMENT_NAME', 'RISK_RATING_NAME']]
    customer_risk = pd.merge(customer_risk, customer_info, on='CUSTOMER_ID', how='left')

    return customer_risk.sort_values('RANK_AVERAGE_RISK')


# Two views of "riskiest":
# - average risk = who mostly deals with risky countries
# - excess amount = who moves the most money through risky countries
def riskiest_customers(customer_risk, top_n=TOP_N):
    in_top_average = customer_risk['RANK_AVERAGE_RISK'] <= top_n
    in_top_excess = customer_risk['RANK_EXCESS_AMOUNT'] <= top_n

    top_average = customer_risk[in_top_average].sort_values('RANK_AVERAGE_RISK')
    top_excess = customer_risk[in_top_excess].sort_values('RANK_EXCESS_AMOUNT')
    in_both = customer_risk[in_top_average & in_top_excess]

    # Customers in either top list that the bank does not rate as High
    not_rated_high = customer_risk[
        (in_top_average | in_top_excess)
        & (customer_risk['RISK_RATING_NAME'] != 'High')
    ]

    return {
        'top_average': top_average,
        'top_excess': top_excess,
        'in_both': in_both,
        'not_rated_high': not_rated_high
    }


def main():
    customer_df = load_customer_data()
    transaction_df = load_transaction_data()

    customer_risk = customer_country_risk(customer_df, transaction_df)
    results = riskiest_customers(customer_risk)

    # Rows are sorted by rank, so the rank columns are only needed in the last list
    top_average = results['top_average'][[
        'CUSTOMER_ID', 'SEGMENT_NAME', 'RISK_RATING_NAME', 'AVERAGE_COUNTRY_RISK', 'TURNOVER'
    ]].copy()
    # Amounts in millions so the tables are easier to read
    top_average['TURNOVER'] = top_average['TURNOVER'] / 1_000_000
    top_average = top_average.rename(columns={'TURNOVER': 'TURNOVER_MIL'})

    print(f'Top {TOP_N} customers by average country risk (amount-weighted, 0-10):')
    print_table(top_average, index=False)

    top_excess = results['top_excess'][[
        'CUSTOMER_ID', 'SEGMENT_NAME', 'RISK_RATING_NAME', 'EXCESS_RISK_AMOUNT', 'TURNOVER'
    ]].copy()
    top_excess['EXCESS_RISK_AMOUNT'] = top_excess['EXCESS_RISK_AMOUNT'] / 1_000_000
    top_excess['TURNOVER'] = top_excess['TURNOVER'] / 1_000_000
    top_excess = top_excess.rename(columns={
        'EXCESS_RISK_AMOUNT': 'EXCESS_RISK_AMOUNT_MIL', 'TURNOVER': 'TURNOVER_MIL'
    })

    print(f'\nTop {TOP_N} customers by excess risk amount (risk above Czech level x amount, millions):')
    print_table(top_excess, index=False)

    print(f"\nCustomers in both top lists: {', '.join(results['in_both']['CUSTOMER_ID'])}")

    print('\nCustomers in a top list that the bank does not rate as High:')
    print_table(results['not_rated_high'][[
        'CUSTOMER_ID', 'SEGMENT_NAME', 'RISK_RATING_NAME', 'RANK_AVERAGE_RISK', 'RANK_EXCESS_AMOUNT'
    ]], index=False)

    print('\nAverage country risk by bank risk rating:')
    rating_summary = customer_risk.groupby('RISK_RATING_NAME')['AVERAGE_COUNTRY_RISK'].agg(
        CUSTOMERS='size', MEAN='mean', MEDIAN='median'
    ).loc[['Low', 'Medium', 'High']]
    print_table(rating_summary)

    TABLE_FOLDER.mkdir(parents=True, exist_ok=True)
    table_path = TABLE_FOLDER / 'customer_country_risk.csv'
    io.save_file(customer_risk.round(4), table_path)
    print(f'\nTable saved to {table_path}')


if __name__ == '__main__':
    main()
