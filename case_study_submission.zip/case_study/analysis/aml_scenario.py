from pathlib import Path
import sys

import pandas as pd

PROJECT_FOLDER = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_FOLDER))

import utils.io as io
from utils.io import load_customer_data, load_transaction_data
from utils.formatting import format_number, print_table


TABLE_FOLDER = PROJECT_FOLDER / 'outputs/tables'

# Red flag: non-domestic high-value transactions involving a risky client
# Scenario: RISK_RATING == 3 and AMOUNT >= 30,000 and TARGET_COUNTRY != 'CZ'
HIGH_RISK = 3
AMOUNT_THRESHOLD = 30_000
HOME_COUNTRY = 'CZ'

ALERT_COLUMNS = [
    'TXN_ID', 'TXN_DATE', 'CUSTOMER_ID', 'SEGMENT_NAME', 'RISK_RATING', 'AMOUNT',
    'CREDIT_DEBIT', 'CASH_NONCASH', 'ORIGIN_COUNTRY', 'TARGET_COUNTRY'
]


# Risk rating lives in the customer table, so it has to be joined to each transaction
def add_customer_info_to_transactions(customer_df, transaction_df):
    customer_info = customer_df[['CUSTOMER_ID', 'SEGMENT_NAME', 'RISK_RATING']]

    transactions = pd.merge(
        transaction_df,
        customer_info,
        on='CUSTOMER_ID',
        how='left'
    )

    # Stop if a transaction has no customer, it could never trigger the scenario
    missing = transactions['RISK_RATING'].isna().sum()
    if missing:
        raise ValueError(f'{missing} transactions have no matching customer')

    return transactions


# transaction.csv stores dates as yyyy-mm-dd, so parse them if the loader did not
def parse_transaction_dates(transactions):
    if not pd.api.types.is_datetime64_any_dtype(transactions['TXN_DATE']):
        transactions['TXN_DATE'] = pd.to_datetime(
            transactions['TXN_DATE'], format='%Y-%m-%d'
        )
    return transactions


def generate_alerts(customer_df, transaction_df):
    transactions = add_customer_info_to_transactions(customer_df, transaction_df)
    transactions = parse_transaction_dates(transactions)

    is_high_risk = transactions['RISK_RATING'] == HIGH_RISK
    is_high_value = transactions['AMOUNT'] >= AMOUNT_THRESHOLD
    is_non_domestic = transactions['TARGET_COUNTRY'] != HOME_COUNTRY

    alerts = transactions[is_high_risk & is_high_value & is_non_domestic]

    return alerts[ALERT_COLUMNS].sort_values(['TXN_DATE', 'TXN_ID']).reset_index(drop=True)


def main():
    customer_df = load_customer_data()
    transaction_df = load_transaction_data()

    alerts = generate_alerts(customer_df, transaction_df)

    print(
        f'Scenario: RISK_RATING == {HIGH_RISK} and AMOUNT >= {format_number(AMOUNT_THRESHOLD, 0)} '
        f"and TARGET_COUNTRY != '{HOME_COUNTRY}'"
    )
    print(f'Alerts: {format_number(len(alerts), 0)} transactions from '
          f'{format_number(alerts["CUSTOMER_ID"].nunique(), 0)} customers')
    print(f'Total alerted amount: {format_number(alerts["AMOUNT"].sum())}')

    # All alerts are in the saved table, here only the first ones
    print('\nFirst 10 alerts:')
    print_table(alerts.head(10), index=False)

    print('\nAlerts by target country:')
    print_table(alerts['TARGET_COUNTRY'].value_counts().rename('ALERTS'))

    print('\nAlerts by segment:')
    print_table(alerts['SEGMENT_NAME'].value_counts().rename('ALERTS'))

    TABLE_FOLDER.mkdir(parents=True, exist_ok=True)
    table_path = TABLE_FOLDER / 'aml_alerts.csv'
    io.save_file(alerts, table_path)
    print(f'\nTable saved to {table_path}')


if __name__ == '__main__':
    main()
